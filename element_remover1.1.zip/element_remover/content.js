// content.js

const HIGHLIGHT_CLASS = 'element-remover-highlight';
const ACTIVE_STATE_CLASS = 'remover-tool-active';

let activeElement = null;
let deletedElements = [];
let isInitialized = false;

// --- GŁÓWNA LOGIKA KOMUNIKACJI ---

chrome.runtime.onMessage.addListener((message) => {
  if (message.command === "activate-remover") {
    initialize();
  } else if (message.command === "execute-cleanup") {
    cleanup();
  }
});

// --- OBSŁUGA ZDARZEŃ ---

const handleMouseOver = (evt) => {
  evt.stopPropagation();
  evt.preventDefault();

  // POWRÓT DO NAJPROSTSZEJ METODY: evt.target
  // To powinno pozwolić na zaznaczenie kontenera mapy/canvas.
  const elementUnderCursor = evt.target;

  if (activeElement && activeElement !== elementUnderCursor) {
    activeElement.classList.remove(HIGHLIGHT_CLASS);
  }

  activeElement = elementUnderCursor;
  if (activeElement && activeElement.classList) {
    activeElement.classList.add(HIGHLIGHT_CLASS);
  }
};

const handleDelete = (evt) => {
  if (evt) {
    evt.stopPropagation();
    evt.preventDefault();
  }
  if (activeElement && typeof activeElement.remove === 'function') {
    if (activeElement === document.body || activeElement === document.documentElement) {
      return;
    }
    
    deletedElements.push({
      element: activeElement,
      parent: activeElement.parentNode,
      nextSibling: activeElement.nextSibling
    });
    
    activeElement.remove();
    activeElement = null;
  }
};

const handleUndo = () => {
  if (deletedElements.length > 0) {
    const { element, parent, nextSibling } = deletedElements.pop();
    if (parent) {
      if (nextSibling && nextSibling.parentNode === parent) {
        parent.insertBefore(element, nextSibling);
      } else {
        parent.appendChild(element);
      }
    }
    activeElement = element;
  }
};

const handleKeyDown = (evt) => {
  const key = evt.key.toLowerCase();
  
  if (key === "delete" || key === "backspace") {
    handleDelete(evt);
  } else if (evt.ctrlKey && key === "z") {
    evt.preventDefault();
    handleUndo();
  } else if (key === "q") {
    chrome.runtime.sendMessage({ command: "cleanup-all-frames" });
  }
};

// --- INICJALIZACJA I CZYSZCZENIE ---

function initialize() {
  if (isInitialized) {
    return;
  }
  isInitialized = true;

  // Aktywuj globalny stan dla CSS
  document.documentElement.classList.add(ACTIVE_STATE_CLASS);

  document.addEventListener("mouseover", handleMouseOver, true);
  document.addEventListener("click", handleDelete, true);
  document.addEventListener("keydown", handleKeyDown, true);
}

function cleanup() {
  if (!isInitialized) {
    return;
  }
  
  // Usuń globalny stan, co natychmiast wyłączy wszystkie style
  document.documentElement.classList.remove(ACTIVE_STATE_CLASS);

  // Usuń klasę z ostatniego aktywnego elementu na wszelki wypadek
  if (activeElement && activeElement.classList) {
    activeElement.classList.remove(HIGHLIGHT_CLASS);
  }

  document.removeEventListener("mouseover", handleMouseOver, true);
  document.removeEventListener("click", handleDelete, true);
  document.removeEventListener("keydown", handleKeyDown, true);

  // Zresetuj stan
  activeElement = null;
  deletedElements = [];
  isInitialized = false;
}